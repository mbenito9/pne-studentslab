import socket
from Seq1 import Seq
import termcolor
ip = "127.0.0.1"
port = 8080

ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

ls.bind((ip,port))
ls.listen()
print("The server is configured")

genes = ["TTTGATCATAGTACTAG", "GTCATATAGAG", "CCCCTTTTG", "CCCCCCGGGA", "ATATCGCATCTCAGCTTC"]

while True:
    print("Waiting for clients to connect")
    try:
        (client_s, c_ip_port) = ls.accept()
    except KeyboardInterrupt:
        print("Server stopped by the user")
        ls.close()
        exit()
    else:
        print("A client has connected to the server!")
        msg_raw = client_s.recv(2048)
        real_msg = msg_raw.decode()
        r = real_msg.strip().split(" ",1)
        comd = r[0]
        termcolor.cprint(comd, "yellow")
        if comd == "PING":
            msg = "OK!\n"
            client_s.send(msg.encode())
            print(msg)
        elif comd == "GET":
            seq = genes[int(r[1])]
            client_s.send((seq + "\n").encode())
            print(seq + "\n")
        elif comd == "INFO":
            seq = Seq(r[1])
            s = f"Sequence: {str(seq)}\n"
            total = seq.len()
            l = s + f"Total length: {total}\n"
            print(l.strip())

            dict_bases = seq.count()
            for base, count in dict_bases.items():
                pct = round((count / total) * 100, 1)
                ans = f"{base}: {count} ({pct}%)\n"
                print(ans.strip())
                l += ans
            client_s.send(l.encode())
        elif comd == "COMP":
            seq = Seq(r[1])
            comp = seq.complement() + "\n"
            print(comp)
            client_s.send(comp.encode())
        elif comd == "REV":
            seq = Seq(r[1])
            rev = seq.reverse() + "\n"
            print(rev)
            client_s.send(rev.encode())
        elif comd == "GENE":
            gene_name = r[1]
            file_name = gene_name + ".txt"
            seq = Seq()
            seq.read_fasta(file_name)
            send_g = str(seq) + "\n"
            print(send_g)
            client_s.send(send_g.encode())
        client_s.close()